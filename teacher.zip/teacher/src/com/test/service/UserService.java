package com.test.service;

import com.test.domain.User;

public interface UserService {

	public boolean login(User user);

}
